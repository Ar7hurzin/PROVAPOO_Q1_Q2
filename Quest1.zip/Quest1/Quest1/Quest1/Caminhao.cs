﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2_Questao1
{
    internal class caminhao : veiculos
    {
        private const int AnoAtual = 2024;
        private int eixos;

        public caminhao(string _placa, int _ano, int _eixos) : base(_placa, _ano)
        {
            this.eixos = _eixos;
            this.Placa = _placa;
            this.Ano = _ano;
        }

        public int Eixos { get => eixos; set => eixos = value; }

        override public string diaria()
        {
            int diariaCalculada = (300 * eixos) - (AnoAtual - this.Ano) * 50;
            return $"R${diariaCalculada},00";
        }
    }
}
