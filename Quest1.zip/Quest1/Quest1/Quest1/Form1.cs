﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace P2_Questao1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void rbCaminhao_CheckedChanged(object sender, EventArgs e)
        {
            btCadastrar.Enabled = true;
            tbAssentos.Visible = true;
            lbAssentos.Visible = true;
            lbAssentos.Text = "Qtd Eixos";
            pcbImagem.Image = Properties.Resources.Caminhao;
            pcbImagem.Visible = true;
        }

        private void lbAssentos_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void rbOnibus_CheckedChanged_1(object sender, EventArgs e)
        {
            btCadastrar.Enabled = true;
            tbAssentos.Visible = true;
            lbAssentos.Visible = true;
            lbAssentos.Text = "Qtd Assentos";
            pcbImagem.Image = Properties.Resources.Onibus;
            pcbImagem.Visible = true;
        }

        private void btCadastrar_Click(object sender, EventArgs e)
        {
            if (!mtbPlaca.MaskFull)
            {
                MessageBox.Show("Você deve preencher o campo: Placa!");
            }
            else if (tbAno.Text == "")
            {
                MessageBox.Show("Você deve preencher o campo: Ano!");
            }
            else if (tbAssentos.Text == "" && rbOnibus.Checked == true)
            {
                MessageBox.Show("Você deve preencher o campo: Qtd Assentos!");
            }
            else if (tbAssentos.Text == "" && rbCaminhao.Checked == true)
            {
                MessageBox.Show("Você deve preencher o campo: Qtd Eixos!");
            }
            else
            {
                string[] veiculos = new string[5];
                if (rbOnibus.Checked == true)
                {
                    onibus onibus = new onibus(mtbPlaca.Text, Convert.ToInt32(tbAno.Text), Convert.ToInt32(tbAssentos.Text));
                    veiculos[0] = Convert.ToString(onibus.Placa);
                    veiculos[1] = Convert.ToString(onibus.Ano);
                    veiculos[2] = Convert.ToString(onibus.Assentos);
                    veiculos[3] = "";
                    veiculos[4] = onibus.diaria();
                }
                else
                {
                    caminhao caminhao = new caminhao(mtbPlaca.Text, Convert.ToInt32(tbAno.Text), Convert.ToInt32(tbAssentos.Text));
                    veiculos[0] = Convert.ToString(caminhao.Placa);
                    veiculos[1] = Convert.ToString(caminhao.Ano);
                    veiculos[2] = "";
                    veiculos[3] = Convert.ToString(caminhao.Eixos);
                    veiculos[4] = caminhao.diaria();

                }

                ListViewItem l = new ListViewItem(veiculos);
                lvVeiculos.Items.Add(l);
                limpar();
                rbCaminhao.Checked = false;
                rbOnibus.Checked = false;
                pcbImagem.Visible = false;
                tbAssentos.Visible = false;
                lbAssentos.Visible = false;
                btCadastrar.Enabled = false;
            }
        }

        private void limpar()
        {
            mtbPlaca.Clear();
            tbAno.Clear();
            tbAssentos.Clear();
        }
        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void mtbPlaca_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void lvVeiculos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void tbEixos_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_2(object sender, EventArgs e)
        {

        }

        private void pcbOnibus_Click(object sender, EventArgs e)
        {

        }

        private void pcbCaminhao_Click(object sender, EventArgs e)
        {

        }

        private void btLimpar_Click(object sender, EventArgs e)
        {
            limpar();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void tbAno_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Define o limite de caracteres
            int maxLength = 4;


            if (tbAno.Text.Length >= maxLength && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
            else
            {
                if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
                {
                    e.Handled = true;
                }
            }
        }


        private void tbAssentos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }
    }
}
